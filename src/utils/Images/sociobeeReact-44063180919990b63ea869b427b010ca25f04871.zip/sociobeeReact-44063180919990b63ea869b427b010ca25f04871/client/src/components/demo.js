import React from 'react'

const Demo = () => {
  return (
    <h1>authorization success</h1>
  )
}

export default Demo